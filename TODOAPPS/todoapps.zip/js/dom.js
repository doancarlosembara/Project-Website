function addTodo(){
	const textTodo = document.getElementById("title").value;
	const timestamp = document.getElementById("date").value;
	console.log("todo" + textTodo);
	console.log("timestamp" + timestamp);
}




